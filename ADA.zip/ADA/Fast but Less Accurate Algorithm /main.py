def fast_vertex_cover(graph):
    cover = set()
    for u in graph:
        if u not in cover:
            for v in graph[u]:
                if v not in cover:
                    cover.add(u)
                    cover.add(v)
                    break  # Move to the next node quickly
    return cover

# Example graph
graph = {
    'A': ['B'],
    'B': ['A', 'C'],
    'C': ['B', 'D'],
    'D': ['C']
}

cover = fast_vertex_cover(graph)
print("Fast (Less Accurate) Vertex Cover:", cover)
