def approx_vertex_cover(graph):
    """
    2-Approximation Greedy Algorithm for Vertex Cover.
    Guarantees cover size ≤ 2 × optimal.
    """
    cover = set()
    edges = set()

    # Build a unique set of undirected edges
    for u, neighbors in graph.items():
        for v in neighbors:
            # Add each edge only once
            if (v, u) not in edges:
                edges.add((u, v))

    # While there are still uncovered edges
    while edges:
        # Take an arbitrary edge (u, v)
        u, v = edges.pop()
        cover.add(u)
        cover.add(v)

        # Remove all edges incident to u or v
        edges = {e for e in edges if u not in e and v not in e}

    return cover


if __name__ == "__main__":
    # Example graph (adjacency list)
    graph = {
        'A': ['B'],
        'B': ['A', 'C'],
        'C': ['B', 'D'],
        'D': ['C']
    }

    cover = approx_vertex_cover(graph)
    print("Accurate (Slower) Vertex Cover:", cover)
